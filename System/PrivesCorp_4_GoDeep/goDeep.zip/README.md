# PrivesCorp #4: Go Deep

### Category

System

### Description

The layoff list was leaked... The reponsible hr was let go, but before that, he barricaded very important information on his account. If you could get to it, there would probably be a promotion in sight.
Your credentials on PrivesCorp's network -> bob:password123

URL : http://challs.heroctf.fr:XXXX

Format : **Hero{flag}**<br>
Author : **Log_s**

### Write up

### Flag

```Hero{H0w_d1d_u_g3t_0u7}```
